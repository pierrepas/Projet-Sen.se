package pilotageLampe_v2;

public class Mqtt_pub {
	//MqttMessage message = new MqttMessage();
	//message.setQos(0);
	//message.setPayload("message from eclipse".getBytes());
}
